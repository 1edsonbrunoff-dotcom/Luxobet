# Frontend

Run:

```
cd frontend
npm install
npm run dev
```
