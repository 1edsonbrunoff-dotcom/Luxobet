import React, { useEffect, useState } from 'react';

export default function HomePage() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch(process.env.NEXT_PUBLIC_API_URL ? process.env.NEXT_PUBLIC_API_URL + '/api/events' : 'http://localhost:4000/api/events')
      .then(r => r.json())
      .then(setEvents)
      .catch(console.error);
  }, []);

  return (
    <main style={{ padding: 24, fontFamily: 'system-ui, sans-serif' }}>
      <h1>LuxoBet — Página pública</h1>
      <p>Lista de eventos (mock)</p>
      <ul>
        {events.map((e: any) => (
          <li key={e.id}>{e.league} — {e.teams} — {new Date(e.start_at).toLocaleString()}</li>
        ))}
      </ul>
      <hr/>
      <p>Admin dashboard disponível em <code>/admin</code> (demo dentro do repo).</p>
    </main>
  );
}
