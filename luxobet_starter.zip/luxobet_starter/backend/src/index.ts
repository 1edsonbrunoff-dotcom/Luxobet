import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_, res) => res.json({ ok: true }));

// Mock events endpoint (replace with DB query / feed integration)
app.get('/api/events', (_, res) => {
  res.json([
    { id: 1, league: 'UEFA Champions League', teams: 'Real Madrid vs PSG', start_at: '2025-11-20T18:45:00Z', odds: { home: 2.10, draw: 3.40, away: 3.10 } },
    { id: 2, league: 'Premier League', teams: 'Liverpool vs Arsenal', start_at: '2025-11-21T16:00:00Z', odds: { home: 1.95, draw: 3.60, away: 4.00 } }
  ]);
});

app.post('/api/bets', (req, res) => {
  // Simplified: validate request and return confirmation
  const { user, selections, stake } = req.body;
  if (!user || !selections || !stake) return res.status(400).json({ error: 'invalid_request' });
  // TODO: reserve funds, create bet record, respond with bet id and potential return
  res.json({ ok: true, betId: 'BET_'+Date.now(), possibleReturn: stake * 1.95 });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend listening on ${PORT}`));
