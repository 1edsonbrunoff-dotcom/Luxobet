# Backend

Run:

```
cd backend
npm install
npm run dev
```
